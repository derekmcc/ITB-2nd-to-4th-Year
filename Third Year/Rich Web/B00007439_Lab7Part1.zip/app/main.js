"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ShoppingCart_1 = require("./ShoppingCart");
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
// App bootstrap.
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(ShoppingCart_1.AppModule);
//# sourceMappingURL=main.js.map