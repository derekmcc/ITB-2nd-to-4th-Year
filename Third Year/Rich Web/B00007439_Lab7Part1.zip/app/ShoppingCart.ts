import {FormsModule} from '@angular/forms';
import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

class Item {
    constructor(public id: number, public name: string, public price: number) {}
}

@Component({
    selector: 'osl-app',
    templateUrl: 'app/ShoppingCart.html'
})
class ShoppingCartComponent {
    items: Array<Item> = [];
    quantity: number = 0;
    lineCost: number = 0;
    tempQ: number = 0;
    tempP: number = 0;
    skills: string = "";
    v: number = 1;
    constructor() {
        this.items.push(new Item(0, 'Skis', 250));
        this.items.push(new Item(1, 'iPad', 3000));
        this.items.push(new Item(2, 'Bugatti', 2000000)); 
        this.lineCost = this.quantity * this.items[0].price;    
    }

    lCost(quantity: number, price: number): number {
        if (quantity == undefined){
            this.lineCost = 0;
        }
        else {
            this.tempP = price;
            this.tempQ = quantity;
            this.lineCost = this.tempQ*this.tempP;
        }
        return this.lineCost; 
    } 
   
    remove(index){
     this.items.splice(index, 1);
    }
 
    getQuantity(): number{
        return this.quantity;
    }//end getPrice
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [ShoppingCartComponent],
    bootstrap: [ShoppingCartComponent]
})
export class AppModule {}