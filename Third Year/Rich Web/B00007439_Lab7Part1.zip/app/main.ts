import {AppModule} from './ShoppingCart';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

