class Employee {
  name: string;
  salary: number;

  constructor(name: string, salary: number) {
    this.name = name;
    this.salary = salary;
  }   
}

var emp1 = new Employee("Lydia", 10000);
