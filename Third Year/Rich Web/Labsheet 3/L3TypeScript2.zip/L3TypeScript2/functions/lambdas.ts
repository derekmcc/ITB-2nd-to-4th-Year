var getFullName = (fname: string, lname: string): string => fname + ' ' + lname;

console.log(getFullName('Peter', 'John'));

