var getFullName = (fname: string, lname: string): string => {
    var fullName: string = fname + ' ' + lname;
    return fullName;
}
