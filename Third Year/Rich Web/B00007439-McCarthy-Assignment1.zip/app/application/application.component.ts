import {Component} from '@angular/core';
import {Restaurant, RestaurantService} from '../restaurant-service/restaurant-service';
import {FormsModule} from '@angular/forms';

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html',
    providers:	 [RestaurantService]
})
export default class ApplicationComponent {
	restaurants: Array<Restaurant> = []; 

    constructor(restaurantService: RestaurantService) {
        this.restaurants = restaurantService.getRestaurants();
    }
}
