import {Component,Input, Output, EventEmitter} from '@angular/core';
import {Restaurant, RestaurantService} from '../restaurant-service/restaurant-service';
import {CountyService} from "../county-service/county-service";
import {County} from "../county/county";
import {Town} from "../town/town";

@Component({
    moduleId: module.id,
    templateUrl: 'home.component.html',
    styleUrls:  ['home.css'],
    providers: [RestaurantService, CountyService]
})
export default class HomeComponent {
    countyChosen: string;
    county: string;
    selectedCounty:County = new County(0, 'Clare');
    counties: County[];
    towns: Town[];
    restaurants: Array<Restaurant> = [];

    @Input() rating: number;

    @Output() ratingClick:EventEmitter<any> = new EventEmitter<any>();

    constructor(private restaurantService: RestaurantService, private countyService: CountyService) {
        this.restaurants = restaurantService.getRestaurants();
        this.counties = this.countyService.getCounties();
    }

    onSelect(countyId: number) {
        this.towns = this.countyService.getTowns().filter((item)=> item.countyId == countyId);
        this.restaurants = this.restaurantService.getRestaurants().filter((item)=> item.countyId == countyId);

        console.log(countyId);
    }

    onClick(rating:number):void{

        this.rating = rating;
        this.restaurants = this.restaurantService.getRestaurants().filter((item)=> item.score == rating);
    }

}
