"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var module_1 = require("./module");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(module_1.default);
//# sourceMappingURL=main.js.map