import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector:    'osl-contact',
    templateUrl: 'contact.html',
    styleUrls: ['contact-style.css'],
})
export default class ContactComponent {}