import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector:    'osl-about',
    templateUrl: 'about.html',
    styleUrls: ['about-style.css'],
})
export default class AboutComponent {}