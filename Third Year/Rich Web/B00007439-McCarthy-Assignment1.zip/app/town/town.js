"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Town = /** @class */ (function () {
    function Town(id, countyId, name) {
        this.id = id;
        this.countyId = countyId;
        this.name = name;
    }
    return Town;
}());
exports.Town = Town;
//# sourceMappingURL=town.js.map