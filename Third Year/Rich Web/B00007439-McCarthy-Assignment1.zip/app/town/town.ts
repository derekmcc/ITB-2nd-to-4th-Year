export class Town {
    constructor(public id: number,
                public countyId: number,
                public name: string) {
    }
}