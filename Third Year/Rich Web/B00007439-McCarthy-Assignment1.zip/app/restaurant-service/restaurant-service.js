"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Restaurant = /** @class */ (function () {
    function Restaurant(id, countyId, townId, name, address, town, county, cuisine, price, score, reviews, openingHours, facilities, menu) {
        this.id = id;
        this.countyId = countyId;
        this.townId = townId;
        this.name = name;
        this.address = address;
        this.town = town;
        this.county = county;
        this.cuisine = cuisine;
        this.price = price;
        this.score = score;
        this.reviews = reviews;
        this.openingHours = openingHours;
        this.facilities = facilities;
        this.menu = menu;
    }
    return Restaurant;
}());
exports.Restaurant = Restaurant;
var RestaurantService = /** @class */ (function () {
    function RestaurantService() {
        this.counties = [];
        this.reviews = [];
        this.menus = [];
        this.tempArray = [];
        this.towns = [];
        this.counties = [
            "Dublin", "Cork", "Clare", "Galway", "Waterford", "Wexford"
        ];
        this.reviews = [
            "As you enter the place you are welcomed by a magnificent setting, a delightful marriage of antique cut stones and the luxuries of modernity. " +
                "Sitting in any table you have a wonderful view of the workshop-like kitchen where you can see the chefs working. For those who do not book a table " +
                "and are waiting, there is a cosy lounge with aged leather armchairs and pictures of polo players displayed on the walls.\n- By Sharon Maloney",
            "The menu offers a wide variety of mouth-watering starters. I had the white asparagus accompanied by a mousseline sauce and poached eggs, while my friend " +
                "tried the zucchini carpaccio served with sundries tomatoes and a mozzarella strudel. They were exquisite. The main course consisted of a risotto with scallop " +
                "cooked in cream and a cassolette of coley with mussels, which really thrilled us. It all was followed by a delicious apple pie served with a scoop of vanilla " +
                "ice cream for dessert. \n - By Jack Carpet",
            "All the products were fresh and the dishes had the warmth of home-made food. The chefs take great care in selecting the best quality ingredients. " +
                "The restaurant also caters for all tastes by providing a large selection of the best wines of the region, which are pricy but worth sampling. \n - By Kim Fox",
            "What a pity that the service does not accompany the high quality of the cooking. You can hardly get a smile out of the waitresses. Thankfully the owner " +
                "and hostess, a middle-aged charming woman, is always around willing to exchange some kind words with all her clients.\n - By Gerry Juke",
            "Despite the high price of the food and the not so attentive waiters´ service, I had a pleasant dining experience with food of the most exquisite " +
                "flavours. For this reason I highly recommend going to the restaurant.\n - By Sid O'Neil",
            "The restaurant is situated in the heart of a small village between three national forests and close to the horse´s capital city, " +
                "Chantilly. It is the favourite hangout place for people from the polo, horse races, and golf world.\n - By Jason Ajax"
        ];
        this.menus = [
            "Flat Iron steak, romaine, anchovy, parmesan & onion €24",
            "Cod, lardo, cauliflower, mussels & bisque €23",
            "Guinea fowl, corn, brown beech, bacon, parmesan agnolotti €25",
            "Partridge, hen of the woods, parsnip, baby leek & blackberry €26",
            "Venison, celeriac, walnut, chanterelle & hispi €26",
            "Duck leg, coco paimpol, prune, cavolo nero & toulouse sausage €21",
            "Glazed Shredded Duck, Pickled Carrots, Orange and Sesame Dressing €9",
            "Salad of Fivemiletown Irish Goats Cheese, Candled Pecans, Figs, Wild Berry Coulls €11",
            "Chicke Liver and Foie Gras Pate, Toasted Brioche, Marinated Cherries, Beurre Noisette €14",
            "Signature Lemon, Garlic and Herb Sauteed Whole Gambas, Rocket, Honey Citrus Dressing €13",
            "White beetroot, William pear, goat’s curd, walnut, Ballyhoura mushroom and fennel, Irish cauliflower, Lindi pepper, fermented horseradish €85",
            "Ox tongue, gribiche, white radish, brown butter, Jerusalem artichoke, Coolea cheese, guanciale, hazelnut, Tartare of mackerel, smoked haddock, sea purslane, Terrine of rose veal and chicken, hen of the woods mushroom, leek vinaigrette, parsley, Grilled lasagne of scallop and Atlantic crab, pickled seaweed butter, red dulse €85",
            "10oz Striploin €20.95",
            "Cajun Chicken Burger €13.95",
            "Smoked Haddock €14.95",
            "Chicken Stir Fry Sizzler €14.95",
            "Chicken Fajita €15.95",
            "Bleecker Cheeseburger and Fries €9.50",
            "Grilled Chicken Burger and Fries €9.50",
            "Omlette €10.50",
            "Kholodets €6.90",
            "Red Caviar With Ciabata €7.90",
            "East Style Aubergines €6.90",
            "Snack Pod Vodochku €7.20",
            "Meat Platter €13.90",
            "Classic Beef Burger €11.90",
            "Fish and Chips €15.90",
            "Chicken Burger €11.90",
            "Hake Fillet & Seared Scallop €29.50",
            "Pan Seared Wild Halibut Fillet €34.00",
            "Macroom Lamb €31.00",
            "Braised Feather Blade of Beef €27.50",
            "Skeaghanore Duck €32.50",
            "Baked Cod, Carrot and swede boxty, sautéed greens, sorrel butter sauce €18.50",
            "Naturally smoked haddock, kedgeree rice, green beans, crispy hen’s egg €16.50",
            "Pork Wellington, forest mushroom duxelles, sautéed sprouts and duck fat roast potatoes €19.00",
            "Ballinwillin wild boar and cider casserole, cavolo nero, grain mustard mash, caramelised apples €18.90",
            "Butler's of Mullinavat Grilled Breast Of Chicken €19.00",
            "Slow Roast Crowe Farm Pork Belly €21.00",
            "Pumpkin, Sunflower & Linseed Burger €16.90",
            "Roast Wild Mushroom risotto €15.90",
            "Fish Dish of the Day €16.00",
            "Formaggio Con Salsa Dolce €8.50",
            "Funghi All Aglio €9.00",
            "Carpaccio Di Manzo €7.50",
            "Zuppa Del Giorno €5.75",
            "Brushcetta Al Pomodoro €7.00",
            "StoneCutters Home-made Seafood Chowder  €6.25",
            "StoneCutters Creamy Ocean Pie €14.95",
            "StoneCutters Fresh Fish and Chips €14.50",
            "Traditional Beef & Guinness Stew €11.95",
            "StoneCutters Home-made Burger €9.95",
            "Slow roast beef striploin, sautéed tiger prawns, brandy and cracked black pepper sauce €22.50",
            "Roast Turkey and cider glazed ham, herb stuffing & cranberry jus €19.50",
            "Pan seared seabream, scallion mash, sweet potato, pea & gremolata €22.50",
            "Oven roast salmon, confit garlic, spinach & onion sauce €21.50",
            "Cep & spinach risotto €14.50",
            "Brasserie Seafood Chowder €6.95",
            "Herring Salad €9.95",
            "Smoked Duck Ham €8.95",
            "Salmon Tasting Plate €10.95",
            "Confit Chicken Leg and Fole Gras Terrine €8.95",
            "Spiced Chicken Burger €12.00, Vegetable Curry €10.95",
            "Moroccan Spiced Vegetable Tagine €12.00",
            "Fall of The Bone Irish Lamb Shank € 19.95",
            "Stew of the Day With Seasoned Vegetables €14.50",
            "Fishmongers Vessel €15.50",
            "10oz Sirloin Steak €25.00",
            "Market Fish €22.00, Lamb Rump €25.00",
            "Garden Filo Tarts €17.00",
            "Herb Chicken €22.00",
            "Miso Glazed Pork Belly €23.00",
            "Grilled Trout €23.00",
            "BBQ’d Monkfish Tail €24.00",
            "Gnocchi €18.00"
        ];
        this.restaurants = [
            new Restaurant(0, 3, 4, 'Mr Fox', '38 Parnell Square West', 'Dublin City', this.counties[0], 'European', 18, 4, [this.reviews[0], this.reviews[3], this.reviews[5]], '9am - 5pm', "Reservations, Seating, Waitstaff, Serves Alcohol", [this.menus[0], this.menus[1], this.menus[2], this.menus[3], this.menus[4], this.menus[5]]),
            new Restaurant(1, 3, 4, 'Bloom Brasserie', '11 Baggot Street Upper', 'Dublin City', this.counties[0], 'European', 21, 5, [this.reviews[1], this.reviews[4]], '8am -4pm', " Outdoor Seating, Reservations, Seating, Waitstaff, Serves Alcohol, Full Bar, Wine and Beer, Free Wifi", [this.menus[6], this.menus[7], this.menus[8], this.menus[9]]),
            new Restaurant(2, 3, 4, 'Chapter One', '18-19 Parnell Sq', 'Dublin City', this.counties[0], 'European', 30, 5, [this.reviews[3], this.reviews[4]], '9am - 9pm', "Reservations, Private Dining, Seating, Waitstaff, Serves Alcohol, Full Bar", [this.menus[10], this.menus[11]]),
            new Restaurant(3, 3, 5, 'The Old School House Bar and Restaurant', 'Church Road', 'Swords', this.counties[0], 'American', 11, 4, [this.reviews[1], this.reviews[2]], '10am - 12am', "Outdoor Seating, Seating, Waitstaff, Parking Available, Television, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Free Wifi", [this.menus[12], this.menus[13], this.menus[14], this.menus[15], this.menus[16]]),
            new Restaurant(4, 3, 4, 'Bleeker Street Cafe Bar', '68 Dorset Street Upper', 'Dublin City', this.counties[0], 'European', 15, 4, [this.reviews[2], this.reviews[5]], '9am - 6pm', "Takeout, Outdoor Seating, Buffet, Seating, Waitstaff, Street Parking, Free Off-Street Parking, Television, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Accepts Mastercard, Accepts Visa, Digital Payments, Free Wifi, Reservations, Accepts Credit Cards", [this.menus[17], this.menus[18], this.menus[19]]),
            new Restaurant(5, 3, 4, 'Admiral Restaurant', '1 Q-Park Ground Floor, Marlborough St', 'Dublin City', this.counties[0], 'European', 27, 5, [this.reviews[1], this.reviews[5]], '9am - 5pm', "Reservations, Seating, Waitstaff, Street Parking, Television, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Wine and Beer, Accepts Mastercard, Accepts Visa, Digital Payments, Free Wifi, Accepts Credit Cards", [this.menus[20], this.menus[21], this.menus[22], this.menus[23], this.menus[24]]),
            new Restaurant(6, 2, 3, 'Liberty Grill', '32 Washington St, Centre', 'Cork City', this.counties[1], 'American', 10, 5, [this.reviews[0], this.reviews[3]], '10am - 7-pm', "Reservations, Seating, Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Wine and Beer, Accepts American Express, Accepts Mastercard, Accepts Visa, Accepts Credit Cards", [this.menus[25], this.menus[26], this.menus[27]]),
            new Restaurant(7, 2, 3, 'Greenes Restaurant', '48 MacCurtain Street', 'Cork City', this.counties[1], 'European', 15, 3, [this.reviews[5], this.reviews[2]], '10am - 10pm', "Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Accepts American Express, Accepts Mastercard, Accepts Visa, Digital Payments, Free Wifi, Reservations, Seating, Accepts Credit Cards", [this.menus[28], this.menus[29], this.menus[30], this.menus[31], this.menus[32]]),
            new Restaurant(8, 2, 3, 'Market Lane', '5-6 Oliver Plunkett St, Centre', 'Cork City', this.counties[1], 'European/Irish', 30, 2, [this.reviews[2], this.reviews[1]], '9am - 6pm', "Outdoor Seating, Reservations, Seating, Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Accepts American Express, Accepts Mastercard, Accepts Visa, Free Wifi", [this.menus[33], this.menus[34], this.menus[35], this.menus[36]]),
            new Restaurant(9, 5, 9, 'Bodega', '54 John St', 'Waterford City', 'Waterford', 'European', 6, 2, [this.reviews[0], this.reviews[2]], '9am - 7pm', "Reservations, Seating, Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Free Wifi", [this.menus[37], this.menus[38], this.menus[39], this.menus[40], this.menus[41]]),
            new Restaurant(10, 5, 8, 'Emilianos', '21 High St', 'Waterford City', 'Waterford', 'European', 12, 1, [this.reviews[0], this.reviews[3]], '7am - 7pm', "Takeout, Reservations, Seating, Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Free Wifi", [this.menus[42], this.menus[43], this.menus[44], this.menus[45], this.menus[46]]),
            new Restaurant(11, 1, 1, 'Stonecutters Kitchen', 'Doolin', 'Clare', 'Clare', 'European', 19, 4, [this.reviews[0]], '9am - 4pm', "Takeout, Reservations, Outdoor Seating, Seating, Waitstaff, Parking Available, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Free Wifi", [this.menus[47], this.menus[48], this.menus[49], this.menus[50], this.menus[51]]),
            new Restaurant(12, 1, 2, 'The Cloister Restaurant & Bar', 'Abbey St, Lifford, Ennis', 'Ennis', 'Clare', 'European', 25, 3, [this.reviews[3]], '9am - 8pm', "Reservations, Private Dining, Seating, Waitstaff, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Free Wifi, Parking Available", [this.menus[52], this.menus[53], this.menus[54], this.menus[55], this.menus[56]]),
            new Restaurant(13, 4, 7, 'Brasserie On The Corner', '25 Eglinton St', 'Salthill', 'Galway', 'European', 40, 3, [this.reviews[0], this.reviews[4]], '8:30am - 6pm', "Waitstaff, Street Parking, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Full Bar, Wine and Beer, Free Wifi, Reservations, Seating", [this.menus[57], this.menus[58], this.menus[59], this.menus[60], this.menus[61]]),
            new Restaurant(14, 4, 6, 'The Quay Street Kitchen', 'Unit B The Halls, Quay Street', 'Galway City', 'Galway', 'European', 23, 5, [this.reviews[0], this.reviews[3], this.reviews[5]], '7am - 4pm', "Outdoor Seating, Seating, Waitstaff, Serves Alcohol, Wine and Beer, Accepts Mastercard, Accepts Visa, Free Wifi, Highchairs Available, Accepts Credit Cards", [this.menus[62], this.menus[63], this.menus[64], this.menus[65], this.menus[66]]),
            new Restaurant(15, 6, 9, 'The Yard Restaurant', '3 Lower Georges Street', 'Wexford City', 'Wexford', 'European', 5, 1, [this.reviews[0], this.reviews[2]], '9am - 6pm', "Takeout, Outdoor Seating, Seating, Waitstaff, Parking Available, Street Parking, Highchairs Available, Wheelchair Accessible, Serves Alcohol, Wine and Beer, Accepts Mastercard, Accepts Visa, Digital Payments, Free Wifi, Reservations, Full Bar, Accepts Credit Cards", [this.menus[67], this.menus[68], this.menus[69], this.menus[70], this.menus[71], this.menus[72], this.menus[73]])
        ];
        this.towns = [
            'Clare City',
            'Cork City',
            'Ennis',
            'Dublin City',
            'Swords',
            'Galway City',
            'Salthill',
            'Waterford City',
            'Waterford City',
            'Wexford City'
        ];
    }
    RestaurantService.prototype.getRestaurants = function () {
        return this.restaurants;
    };
    RestaurantService.prototype.getRestaurantById = function (id) {
        return this.restaurants[id];
    };
    RestaurantService.prototype.getCounties = function () {
        return this.counties;
    };
    RestaurantService.prototype.getCountyById = function (id) {
        return this.counties[id];
    };
    RestaurantService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], RestaurantService);
    return RestaurantService;
}());
exports.RestaurantService = RestaurantService;
//# sourceMappingURL=restaurant-service.js.map