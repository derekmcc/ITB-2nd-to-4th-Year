"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var town_1 = require("../town/town");
var county_1 = require("../county");
var CountyService = /** @class */ (function () {
    function CountyService() {
    }
    CountyService.prototype.getCounties = function () {
        return [
            new county_1.County(1, 'Clare'),
            new county_1.County(2, 'Cork'),
            new county_1.County(3, 'Dublin'),
            new county_1.County(4, 'Galway'),
            new county_1.County(5, 'Waterford'),
            new county_1.County(6, 'Wexford')
        ];
    };
    CountyService.prototype.getTowns = function () {
        return [
            new town_1.Town(1, 1, 'Clare City'),
            new town_1.Town(2, 1, 'Ennis'),
            new town_1.Town(3, 2, 'Cork City'),
            new town_1.Town(4, 3, 'Dublin City'),
            new town_1.Town(5, 3, 'Swords'),
            new town_1.Town(6, 4, 'Galway City'),
            new town_1.Town(7, 4, 'Salthill'),
            new town_1.Town(8, 5, 'Waterford City'),
            new town_1.Town(9, 6, 'Wexford City')
        ];
    };
    CountyService = __decorate([
        core_1.Injectable()
    ], CountyService);
    return CountyService;
}());
exports.CountyService = CountyService;
//# sourceMappingURL=county-service.js.map