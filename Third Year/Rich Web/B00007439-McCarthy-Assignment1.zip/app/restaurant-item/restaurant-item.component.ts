// Implement FilmItemComponent here.
import {Component, Input, OnInit, OnDestroy} from '@angular/core';
import {Restaurant, RestaurantService} from '../restaurant-service/restaurant-service';
import {ActivatedRoute} from '@angular/router';

@Component({
    moduleId:     module.id,
    selector:    'osl-restaurant-item',
    templateUrl: 'restaurant-item.component.html',
    providers:   [RestaurantService]
})

export default class RestaurantItemComponent implements OnInit, OnDestroy {
    @Input() restaurant: Restaurant;
    @Input('score') score: number;
    reviews: Array<string> = [];
    menus: Array<string> = [];

    constructor(private restaurantService: RestaurantService, private route: ActivatedRoute) {}
    subscriberParams: any;

    num: number;
   	imageUrl: String;
    mapImageUrl: String;

    ngOnInit() {
        this.subscriberParams = this.route.params.subscribe(params => {
            let id: number = + params['id'];   // (+) converts string 'id' to a number
            this.restaurant = this.restaurantService.getRestaurantById(id);
        });

        this.reviews = this.restaurant.reviews;
        console.log(this.reviews);
    	this.imageUrl = '/images/' + this.restaurant.id + '.jpg';
        this.mapImageUrl = '/images/map/' + this.restaurant.id + '.jpg';
    	this.num = this.restaurant.score;
    	this.menus = this.restaurant.menu;
    }
    ngOnDestroy() {
        this.subscriberParams.unsubscribe();
    }
}