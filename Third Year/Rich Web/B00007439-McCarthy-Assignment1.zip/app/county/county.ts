export class County {
    constructor(public id: number, public name: string) { }
}