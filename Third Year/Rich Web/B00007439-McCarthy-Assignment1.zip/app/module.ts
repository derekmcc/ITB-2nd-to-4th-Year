import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';

import ApplicationComponent from './application/application.component';
import MenuBarComponent from './menubar/menubar.component';
import FooterComponent from './footer/footer.component';
import RestaurantItemComponent from './restaurant-item/restaurant-item.component';
import ScoreComponent from './score/score.component';
import ReviewComponent from './review/review-component';
import PageNotFoundComponent from './pagenotfound/pagenotfound.component';
import HomeComponent from './home/home.component';
import ContactComponent from './contact/contact.component';
import AboutComponent from './about/about.component';

@NgModule({
    imports: [
    	BrowserModule,
        FormsModule,
        RouterModule.forRoot([
            { path: '', redirectTo: '/home', pathMatch: 'full' },
            { path: 'home', component: HomeComponent },
            { path: 'about', component: AboutComponent },
            { path: 'contact', component: ContactComponent },
            { path: 'restaurants/:id', component: RestaurantItemComponent},
            { path: 'restaurants/:county', component: RestaurantItemComponent},
            { path: '**', component: PageNotFoundComponent }
        ]),
        ],
    declarations: [
    	ApplicationComponent,
     	MenuBarComponent, 
     	RestaurantItemComponent,
     	FooterComponent, 
     	ScoreComponent, 
     	ReviewComponent,
        AboutComponent,
        PageNotFoundComponent,
        HomeComponent,
        ContactComponent
        ],
    providers: [
        {provide: "IS_DEV_ENV", useValue: false},
        {provide: "IS_QA_ENV",  useValue: false}
    ],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


