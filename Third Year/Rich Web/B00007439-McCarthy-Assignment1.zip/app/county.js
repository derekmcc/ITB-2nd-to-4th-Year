"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var County = /** @class */ (function () {
    function County(id, name) {
        this.id = id;
        this.name = name;
    }
    return County;
}());
exports.County = County;
//# sourceMappingURL=county.js.map