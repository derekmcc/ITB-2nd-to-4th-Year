// Implement FilmItemComponent here.
import {Component, Input, OnInit} from '@angular/core';
import {Film} from '../film-service/film-service';
import {Review} from '../review/review-component';
import {ReviewTrackerService} from '../logger-service/ReviewTrackerService';

@Component({
    moduleId:     module.id,
    selector:    'osl-film-item',
    templateUrl: 'film-item.component.html',
    providers:  [ReviewTrackerService]
})
export default class FilmItemComponent implements OnInit {
    @Input() film: Film;
    @Input('score') score: number;
   // @Input('review') reviews: string;
    num: number;
   	imageUrl: String;
    rv: Array<string>;
 //   review: Review;
    ngOnInit() {
    	this.imageUrl = '/images/' + this.film.id + '.jpg';
    	this.num = this.film.score;
      this.rv = this.film.reviews;
    }
}