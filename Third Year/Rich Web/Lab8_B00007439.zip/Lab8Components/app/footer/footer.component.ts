// Implement FooterComponent here.
import {Component} from '@angular/core';

@Component({
    selector: 'osl-footer',
    moduleId: module.id,
    templateUrl: 'footer.component.html'
})
export default class FooterComponent {}
