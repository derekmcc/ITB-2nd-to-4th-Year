
import {Component} from '@angular/core';

@Component({
    selector: 'osl-menubar',
    moduleId: module.id,
    templateUrl: 'menubar.component.html'
})
export default class MenuBarComponent {}