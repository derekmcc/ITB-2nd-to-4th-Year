import {Component} from '@angular/core';
import {Film} from '../film-service/film-service';
import {Injectable} from '@angular/core';
import {ReviewTrackerService} from '../logger-service/ReviewTrackerService';

class Config {
    constructor(public restUrl: string, public secure: boolean) {}
}

@Component({
    selector: 'osl-review',
    moduleId: module.id,
    templateUrl: 'review-component.html',
    providers:[ReviewTrackerService]
})

@Injectable()
export default class ReviewComponent {
	constructor(private loggerService: ReviewTrackerService) {}
	film: Film;
	public reviews: string[] = [];
	public counter: number = 0;
	 textValue = 'initial value';
	public log: string = '';
	public msg: string = "Please leave a review";

  addReview(value: string): void {
  	this.reviews.push(value);
  	this.counter++;
  	this.log = '' + this.counter; 
  	this.msg = "Please leave a review"; 
  	this.loggerService.log("Review " + this.counter + " is " + value);
  //	this.loggerService.log(`Configuration info: ${config.restUrl}, ${config.secure}`);
  }

  reviewLogger() {
  	for(var i = 0; i < this.reviews.length; i++) {
  		this.loggerService.log("Review " + (i+1) + " is " + this.reviews[i]);
  	}
  }
}