import {Component} from '@angular/core';
import {Film, FilmService} from '../film-service/film-service';
import {FormsModule} from '@angular/forms';
import {ReviewTrackerService} from '../logger-service/ReviewTrackerService';


class Config {
    constructor(public restUrl: string, public secure: boolean) {}
}
@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html',
    providers:	 [FilmService, ReviewTrackerService,
     {    
            provide: Config, 
            useFactory: (isDev: boolean, isQA: boolean) => {
                if (isDev || isQA) {
                    return new Config('This is the brief review', false);
                }
                else {
                    return new Config("This is the Verbose review", true);
                 }
            },
            deps: ["IS_DEV_ENV", "IS_QA_ENV"] 
        }]
})
export default class ApplicationComponent {
	films: Array<Film> = []; 

    constructor(loggerService: ReviewTrackerService,  config: Config) { 
        let filmService = new FilmService();
        this.films = filmService.getFilms();
        loggerService.log('ApplicationComponent created'); 
        loggerService.log(`Configuration info: ${config.restUrl}, ${config.secure}`);
    }
}
