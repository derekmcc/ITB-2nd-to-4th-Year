// TODO: Add Angular import statements here...
import {Component}              from '@angular/core';
import {NgModule}               from '@angular/core';
import {BrowserModule}          from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

// Film model class - this Film class is already complete.
class Film {

    private static nextId: number = 0;
    public id: number;
    public genres: string[] = [];
  	public reviews: string[] = [];
    constructor(
        public title: string,
        public blurb: string,
        public price: number,
        public score: number) { 
            this.id = Film.nextId++;
    }
  
    addGenre(...genres: string[]) : void {
        for (let genre of genres) {
            this.genres.push(genre);
        }
    }
  
    genresAsString() : string {
        return this.genres.join(', ');
    }

    addReview(...reviews: string[]) : void {
        for (let review of reviews) {
            this.reviews.push(review);
        }
    }
  
    getReview(rv: number) : string {
        return this.reviews[rv];
    } 
}

// TODO: Define an Angular component named FilmItemComponent here.
@Component({
	selector: 'filmItemComponent',
	templateUrl: 'film-item.html',
	styleUrls: ['film-item.css']
})
class FilmItemComponent {
	
    film: Film;

	constructor() {
		this.film = new Film('John Wick', 'An ex-hitman comes out of retirement to track down the gangsters that took everything from him.', 13.99, 5);
		this.film.addGenre('Action', 'Thriller', 'Crime');
		this.film.addReview("John Wick, is not only a return to badass form for the actor, it's also one of the most excitingly visceral action flicks I've seen in ages.", 
			"A lean, spare, stylish and grimly, methodically ultra-violent extravaganza that provides star Keanu Reeves with a much-needed infusion of cool. And hard-core action fans with combat-centric cinematic expertise on a par with 20ll’s “The Raid.”");
	}
}

// TODO: Wrap the FilmItemComponent component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [FilmItemComponent],
    bootstrap: [FilmItemComponent]
})
export class AppModule {}

// TODO: App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);