public class StackReferenceBased implements StackInterface
{
  private Node top;

  public StackReferenceBased()
  {
    // Stack will be empty when constructed
    // NOTE: top = null is the definition of an empty stack
    top = null;
  }  // end default constructor
  

  public boolean isEmpty()
  {
    // Return if top == null
    return top ==  null;
  }  // end isEmpty

  public void push(Object newItem)
  {
    // INSERT AT THE HEAD OF THE LIST
    // top will always reference the head of the list
    // Create a new Node with the item data
    // Make the new nodes nxt reference the current top of the stack
    // Make the top of the stack reference the new Node
  }  // end push

  public Object pop() throws StackException
  {
    if (/* The stack is not empty*/)
    {
      // Take a copy of the top of the stack to be returned by pop
      // Reset the top ref to the next node
      // Return the copy
    }
    else
    {
      // pop on empty stack : Throw a StackException here
      
    }  // end if
  }  // end pop

  public void popAll()
  {
    // Make the stack empty again - see def of empty stack above
  }  // end popAll

  public Object top() throws StackException
  {
    if (/* The stack is not empty*/)
    {
      // Return a copy of the top item - don't pop it 
    }
    else
    {
      // top on empty stack : Throw a StackException here
    }  // end if

  } // end peek

}  // end StackReferenceBased