// ****************************************************
// Reference-based implementation of ADT list.
// ****************************************************
public class ListReferenceBased implements ListInterface {
  // reference to linked list of items
  private Node head; 
  private int numItems; // number of items in list

  public ListReferenceBased() {
  }  // end default constructor

  public boolean isEmpty() {
  }  // end isEmpty

  public int size() {
  }  // end size

  private Node find(int index) {
  // --------------------------------------------------
  // Locates a specified node in a linked list.
  // Precondition: index is the number of the desired
  // node. Assumes that 1 <= index <= numItems+1 
  // Postcondition: Returns a reference to the desired 
  // node.
  // --------------------------------------------------
  } // end find

  public Object get(int index) 
                throws ListIndexOutOfBoundsException {
  } // end get

  public void add(int index, Object item)
                  throws ListIndexOutOfBoundsException {
  }  // end add

  public void remove(int index) 
                   throws ListIndexOutOfBoundsException {
  }   // end remove

  public void removeAll() {
    // setting head to null causes list to be
    // unreachable and thus marked for garbage 
    // collection
  } // end removeAll
} // end ListReferenceBased