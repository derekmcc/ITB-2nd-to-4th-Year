class ADTDList implements DListInterface
{

	Node head;
	Node tail;
	int numItems;
	
	// TODO: Implement list operations here
	
}