class TestDList
{
	public static void main (String args[])
	{
		ADTDList dList= new ADTDList();
		try {

			dList.add(0, new Integer(5));
			dList.add(1, new Integer(10));
			dList.add(2, new Integer(6));
			dList.add(3, new Integer(12));
			dList.add(4, new Integer(20));
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}
		
		System.out.println("Head to tail output....");
		dList.displayHead2Tail();
		
		System.out.println("Tail to head output....");
		dList.displayTail2Head();

		// TODO: write a test to check for insertion in the middle of the list

		// TODO: write a test to check for deletion of the head

		// TODO: write a test to check for deletion of a non existing index 

		
	}
}