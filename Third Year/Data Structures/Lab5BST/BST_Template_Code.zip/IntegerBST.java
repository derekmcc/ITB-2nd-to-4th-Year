import java.util.ArrayList;

public class IntegerBST implements IntegerBSTInterface { 
	private BNode root;
		
	public IntegerBST(){
		// Empty tree, set the root to null
	}
	
	// Add operation
	public void add(int d){
		if (root == null)
			root = new BNode(d);
		else
			add(root, d);
	}
	private void add(BNode node, int d){
		if (d < node.data()){
			// This value should go to the left of node
			// if the left of node is empty, then add the new node here
			// else if the left of node is occupied, then call add recursively left
		}
		else if (d > node.data()){
			// This value should go to the right of node
			// if the right of node is empty, then add the new node here
			// else if the right of node is occupied, then call add recursively right
		}
	}
	
	// Helper function to return the max of two values
	// Used in the recursive Height method
	private int max(int a,int b){ return a >= b? a:b;}
	
	// Public version of Height - non-recursive
	public int height(){
		return height(root);
	}
	// Private version of height - recursive
	private int height(BNode rt){
		if(rt == null) 
			return 0; 
		else{
			// Result will be ..
			// return 1 + the max of height of left subtree and height of right subtree
			// NOTE: the height of left and right subtrees can be found recursively
		}
	}
	
	// Public version of contains - non-recursive
	public boolean contains(int d){ 
		return contains(root, d);
	}
	
	private boolean contains(BNode node, int d){
		if(node == null) 
			return false; 
		else{
			if(node.data() == d) 
				// We found it
				return true; 
			else if (d < node.data()) 
				// return recursive call down left subtree
			else 	
				// return recursive call down right subtree
		} 
	}
	
	// Public version of inOrder - non recursive
	public ArrayList inOrder(){ 
		ArrayList lst = new ArrayList(); 
		// Recursive call
		inOrder(root,lst);
		return lst;
	}
	// Private version of inOrder - recursive so need to pass root etc
	private void inOrder(BNode node, ArrayList lst){ 
		if(node != null){
			inOrder(node.left(), lst); //process left sub-tree
			lst.add(node.data()); //process root
			inOrder(node.right(),lst); //process right sub-tree
		} 
	}
	// Public version of preOrder - non recursive
	public ArrayList preOrder(){ 
		ArrayList lst = new ArrayList(); 
		// Call to preOrder
		return lst;
	}
	// Private version of preOrder - recursive so need to pass root etc
	private void preOrder(BNode node, ArrayList lst){
		// TODO
	}
	// Public version of postOrder - non recursive
	public ArrayList postOrder(){ 
		ArrayList lst = new ArrayList(); 
		// Call postOrder
		return lst;
	}
	// Private version of postOrder - recursive so need to pass root etc
	private void postOrder(BNode node, ArrayList lst){
		// TODO
	}
	
	// Helper - function to find the maximum value from a root node
	private BNode findMax(BNode node)
	{
		while(node.right() != null) node = node.right();
			return node;
	}
	// Public version of remove, non-recursive
	public void remove(int d){
		root = remove(root, d);
	}
	// Private version of remove, recursive
	private BNode remove(BNode node, int d){
		if (node == null) return null;
		else if (d < node.data()) node.setLeft(remove(node.left(), d));
		else if (d > node.data()) node.setRight(remove(node.right(), d));
		else{
			// Found the node - ready to delete
			// Case 1 : Leaf node
			// If both left and right are empty then just set to null
			
			// Case 2: One child
			// Node to delete has just one child, so replace it with either its left or right child
			
			// Case 3 : Two children
			else{
				/*
				Replace the value in the node to be deleted by the rightmost
				element in its left sub-tree and then delete this node
				NOTE: use findMax to make the replacement and this
				case reduces to case 2 recursive call to remove.
				*/
			}
		}
		return node;
	}
	
	
	

} // End class