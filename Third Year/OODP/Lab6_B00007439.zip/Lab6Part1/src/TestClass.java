
public class TestClass {

	public static void main(String[] args) {
		
		//Create alligator and lizard objects
		AlligatorAdapter alligator = new AlligatorAdapter(10);
		LizardAdapter lizard = new LizardAdapter(1);
		
		//call the feed methods for both objects
		alligator.feed();
		lizard.feed();
	}//end main method
}//end class
