
import zoo.Animal;
import zoo.alligator;

public class AlligatorAdapter extends Animal {
	
	public alligator al;
	
	public AlligatorAdapter(int weight) {
		al = new alligator(weight);	
	}//end constructor
	
	public void feed(){
		al.feedalligator();
	}//end method
}//end class
