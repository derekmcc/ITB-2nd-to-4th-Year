import zoo.Animal;
import zoo.lizard;

public class LizardAdapter extends Animal {
	
	public lizard lz;
	
	public LizardAdapter(int weight) {
		lz = new lizard(weight);
	}//end constructor
	
	public void feed(){
		lz.feedlizard();
	}//end method
}//end class
