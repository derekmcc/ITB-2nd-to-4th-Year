
import java.io.*;
import java.util.*;


public class HexList extends NumberList
{
	int size;

	HexList(String list)
	{
		size = 0;
		
		
		
		StringTokenizer token = new StringTokenizer(list);

		size = token.countTokens();
		
		// Allocate some space for the array
		hex_list = new int[size];

		// Store each list item an the appropriate array
		for(int i = 0; i < size; i++)
		{
			hex_list[i] = Integer.parseInt(token.nextToken(),16);
		}
	}

	public Number sum()
	{
		int n = 0;

		for(int i = 0; i < size; i++)
		{
		   n = n + hex_list[i];
		}
		return new Integer(n);
	}

	public void display()
	{
		System.out.println("Hex List");
		for(int i = 0; i < size; i++)
			System.out.println("[" + i + "] = " + hex_list[i]);
	}
}
