

public class NumberFactory {
	public NumberList getNumberList(String list) {
		
		// Check for  existence of '.'
		int i = list.indexOf('.');
		int x = list.indexOf("0x");
		int y = list.indexOf(",");

		if (i != -1) {
			return new DoubleList(list);
		}
		else if(y != -1) {	
			list = list.replaceAll(",", "");
			return new StringList(list);
		}
		else if (x != -1) {
			list = list.replaceAll("0x", "");
			return new HexList(list);
		}
		else {
			return new IntList(list);
		}
		
	}
}
