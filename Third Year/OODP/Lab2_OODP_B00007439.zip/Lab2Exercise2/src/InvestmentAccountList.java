import java.util.StringTokenizer;

public class InvestmentAccountList extends AccountList {
	
	int size;

	InvestmentAccountList(String list) {
		size = 0;

		StringTokenizer token = new StringTokenizer(list);

		size = token.countTokens();

		// Allocate some space for the array
		iAccount_list = new String[size];

		// Store each list item an the appropriate array
		for(int i = 0; i < size; i++) {
			iAccount_list[i] = token.nextToken();
		}
	}

	public void display() {
		System.out.println("Investment Account List");
		for(int i = 0; i < size; i++)
			System.out.println("[" + i + "] = " + iAccount_list[i]);
	}
}
