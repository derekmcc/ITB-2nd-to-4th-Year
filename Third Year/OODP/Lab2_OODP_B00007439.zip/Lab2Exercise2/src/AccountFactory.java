

public class AccountFactory {
	
	public AccountList getAccountList(String list) {
		
		int i = list.indexOf('I');
		int c = list.indexOf('C');
		
		if (c != -1) {
			list = list.replaceAll(",", "");
			return new CurrentAccountList(list);
		}
		else if(i != -1) {
			list = list.replaceAll(",", "");
			return new InvestmentAccountList(list);
		}
		return null;
	}
}
