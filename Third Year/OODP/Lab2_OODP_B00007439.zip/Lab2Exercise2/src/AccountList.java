
public abstract class AccountList {
	
	protected String[] cAccount_list;
	protected String[] iAccount_list;
	
	AccountList() {
		cAccount_list = null;
		iAccount_list = null;
	}//end constructor

	public String[] getCurrentList() {return cAccount_list;}
	public String[] getInvestmentList() {return iAccount_list;}
	public void display() {}
}
