
public class AccountFactoryTest {
	public static void main(String[] args) {
		
		String list1 = new String("C10001, C10002, C10003, C10004, C10005, C10006");
		String list2 = new String("I20001, I20002, I20003, I20004, I20005, I20006");

		AccountFactory afactory = new AccountFactory();

		System.out.println("");
		AccountList accountlist1 = afactory.getAccountList(list1);
		accountlist1.display();

		System.out.println("");
		AccountList accountlist2 = afactory.getAccountList(list2);
		accountlist2.display();

	}
}
