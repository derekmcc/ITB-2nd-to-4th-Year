import java.util.StringTokenizer;

public class CurrentAccountList extends AccountList {
	
	int size;

	CurrentAccountList(String list) {
		size = 0;

		StringTokenizer token = new StringTokenizer(list);

		size = token.countTokens();

		// Allocate some space for the array
		cAccount_list = new String[size];

		// Store each list item an the appropriate array
		for(int i = 0; i < size; i++) {
			cAccount_list[i] = token.nextToken();
		}
	}

	public void display() {
		System.out.println("Current Account List");
		for(int i = 0; i < size; i++)
			System.out.println("[" + i + "] = " + cAccount_list[i]);
	}
}
