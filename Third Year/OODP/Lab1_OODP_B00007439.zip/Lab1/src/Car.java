
public class Car extends Vehicle{
	
	private int numberOfDoors;
	
	public Car() {
		super();
		numberOfDoors = 0;
	}//end default constructor
	
	public Car(String colour, String type, double engineSize, double netPrice, int numberOfDoors) {
		super(colour, type, engineSize, netPrice);
		this.numberOfDoors = numberOfDoors;
	}//end default constructor
	
	public int getNumberOfDoors() {
		return numberOfDoors;
	}
	public void setNumberOfDoors(int numberOfDoors) {
		this.numberOfDoors = numberOfDoors;
	}
	
	public String toString() {
		return super.toString() + "\nNumber of doors: " + numberOfDoors;
	}//end toString
}//end class
