
public class Test1 {

	public static void main(String[] args) {
		
		Student student1 = new Student();
		
		student1.setStudentNumber("B00007439");
		student1.setName("Derek McCarthy");
		student1.setAddress("Dublin");
		student1.setPhoneNo(1234567890);
		student1.setCourse("Computing");
		
		System.out.println("Student No: \t" + student1.getStudentNumber());
		System.out.println("Name: \t\t" + student1.getName());
		System.out.println("Address: \t" + student1.getAddress());
		System.out.println("Phone No: \t" + student1.getPhoneNo());
		System.out.println("Course: \t" + student1.getCourse());
	}//end main method

}
