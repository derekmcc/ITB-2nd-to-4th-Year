
public class Motorbike extends Car{
	
	private boolean carrier;
	
	public Motorbike() {
		super();
		carrier = false;
	}//end default constructor
	
	public Motorbike(String colour, String type, double engineSize, double netPrice, int numberOfDoors, boolean carrier) {
		super(colour, type, engineSize, netPrice, numberOfDoors);
		this.carrier = carrier;
	}//end default constructor
	
	public boolean isCarrier() {
		return carrier;
	}

	public void setCarrier(boolean carrier) {
		this.carrier = carrier;
	}
	
	public double VRT () {
		return super.getNetPrice() * .13;
	}//end 
	
	public String toString() {
		return super.toString() + "\nCarrier: " + (carrier ? "Yes" : "No" );
	}
}//end class
