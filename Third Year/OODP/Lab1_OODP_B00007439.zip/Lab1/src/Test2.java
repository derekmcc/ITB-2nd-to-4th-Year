
public class Test2 {

	public static void main(String[] args) {
		
		String border = "*******************************************";
		Person p1 = new Person();
		Person p2 = new Person("B1234567", "Fred", "Cork", "Business", 4841234);
		
		System.out.println(border);
		System.out.println("Default Constructor");
		System.out.println(border);
		System.out.println("Student No: \t" + p1.getStudentNumber());
		System.out.println("Name: \t\t" + p1.getName());
		System.out.println("Address: \t" + p1.getAddress());
		System.out.println("Phone No: \t" + p1.getPhoneNo());
		System.out.println("Course: \t" + p1.getCourse());
		
		System.out.println("\n"+border);
		System.out.println("User Defined Constructor");
		System.out.println(border);
		System.out.println("Student No: \t" + p2.getStudentNumber());
		System.out.println("Name: \t\t" + p2.getName());
		System.out.println("Address: \t" + p2.getAddress());
		System.out.println("Phone No: \t" + p2.getPhoneNo());
		System.out.println("Course: \t" + p2.getCourse());
	}//end main method
}//end class
