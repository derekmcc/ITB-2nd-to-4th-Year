
public class Person extends Student{
	
	//default constructor
	public Person() {
		super();
	}//end default constructor
	
	//user defined constructor
	public Person(String studentNo, String name, String address, String course, int phoneNo){
		super.setName(name);
		super.setStudentNumber(studentNo);
		super.setAddress(address);
		super.setCourse(course);
		super.setPhoneNo(phoneNo);
	}//end user defined constructor
}//end class
