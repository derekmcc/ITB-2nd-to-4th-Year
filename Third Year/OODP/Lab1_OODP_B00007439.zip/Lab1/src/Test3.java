
public class Test3 {

	public static void main(String[] args) {
		
		String border = "\n*******************************************\n";
		Car c1 = new Car("White","BMW", 2.5,50.999, 4);
		Motorbike m1 = new Motorbike("Red", "Yamaha", 0.750, 12.999,0,true);
		Motorbike m2 = new Motorbike("Red", "Yamaha", 0.750, 50.999,0,true);
		System.out.println(border+"Car"+c1.toString() + border);
		System.out.println(border+"Motorbike"+m1.toString()+border);
		System.out.println(border+"Motorbike"+m2.toString()+border);
	}//end main method
}//end class
