
public class Vehicle {
	
	private String colour, type;
	private double engineSize, netPrice;
	
	public Vehicle() {
		colour = "";
		type = "";
		engineSize = 0;
		netPrice = 0;
	}//end default constructor
	
	public Vehicle(String colour, String type, double engineSize, double netPrice) {
		this.colour = colour;
		this.type = type;
		this.engineSize = engineSize;
		this.netPrice = netPrice;
	}//end default constructor
	
	public double VRT () {
		return this.netPrice * .21;
	}//end 
	
	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getEngineSize() {
		return engineSize;
	}

	public void setEngineSize(double engineSize) {
		this.engineSize = engineSize;
	}

	public double getNetPrice() {
		return netPrice;
	}

	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	
	public String toString() {
		return "\nColour: " + colour + "\nType: " + type + "\nEngine Size: " + engineSize +" Litres"+ 
				"\nNet Price: �"+ netPrice + "\nVRT: �" + VRT();
	}
}//end class
