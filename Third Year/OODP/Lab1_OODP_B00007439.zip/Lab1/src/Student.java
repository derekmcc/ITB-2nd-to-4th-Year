
/**
 * @author Derek McCarthy B00007439
 *
 */
public class Student {
	
	private String studentNumber, name, address, course;
	private int phoneNo;
	
	public Student() {	
		studentNumber = "";
		name = "";
		address = "";
		course = "";
		phoneNo = 0;
	}//end default constructor
	
	public String getStudentNumber() {
		return studentNumber;
	}//end getStudentNumber

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}//end setStudentNumber

	public String getName() {
		return name;
	}//end getName

	public void setName(String name) {
		this.name = name;
	}//end setName

	public String getAddress() {
		return address;
	}//end getAddress

	public void setAddress(String address) {
		this.address = address;
	}//end setAddress

	public String getCourse() {
		return course;
	}//end getCourse

	public void setCourse(String course) {
		this.course = course;
	}//end setCourse

	public int getPhoneNo() {
		return phoneNo;
	}//end getPhoneNo

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}//end setPhoneNo

}//end class
