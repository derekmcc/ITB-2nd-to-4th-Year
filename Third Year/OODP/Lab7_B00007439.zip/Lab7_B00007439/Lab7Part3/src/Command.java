public interface Command    {
   public void Execute();
   public void unDo();
}
