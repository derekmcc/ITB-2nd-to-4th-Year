import java.awt.FileDialog;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class UpdateCommand implements Command{
	
	JFrame frame;
	
	public UpdateCommand(JFrame fr) {
		frame = fr;
    }
	
    public void Execute() {
	   JOptionPane.showMessageDialog(frame,
		    "Update menu selected",
		    "Update message",
		    JOptionPane.PLAIN_MESSAGE);
    }
}
