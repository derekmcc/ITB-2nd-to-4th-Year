import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Vector;

public class Leaf extends AbstractTask{

	public Leaf(String initName, int initTime) {
        name = initName;
        time = initTime;
        leaf = true;
    }
    
    public Leaf(Leaf initParent, String initName, int initTime) {
        name = initName;
        time = initTime;
        parent = initParent;
        leaf = true;
    }

    public int getTime() {
        return time;
    }

    public String getName() {
        return name;
    }

    public boolean add(Leaf l) throws NoSuchElementException {
        throw new NoSuchElementException("No subordinates");
    }

    public void remove(Leaf l) throws NoSuchElementException {
        throw new NoSuchElementException("No subordinates");
    }

    public Enumeration subordinates () {
        Vector v = new Vector();
        return v.elements ();
    }

    public Leaf getChild(String s) throws NoSuchElementException {
        throw new NoSuchElementException("No children");
    }

    public int getTimes() {
        return time;
    }

    public Leaf getParent() {
        return parent;
    }
}
