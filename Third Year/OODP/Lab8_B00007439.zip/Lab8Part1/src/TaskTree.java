import java.awt.*;
import java.awt.event.*;
import java.util.*;

//swing classes
import javax.swing.text.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.tree.*;


public class TaskTree extends Windoze implements TreeSelectionListener {
    Leaf projects, sap, website, payroll;
    Leaf analysis, coding;
   

    JScrollPane sp;
    JPanel treePanel;
    JTree tree;
    DefaultMutableTreeNode troot;
    JLabel cost;

    public TaskTree() {
        super("Task tree");
        makeLeaves();
        setGUI();
    }
    //--------------------------------------
    private void setGUI() {
        treePanel = new JPanel();
        getContentPane().add(treePanel);
        treePanel.setLayout(new BorderLayout());

        sp = new JScrollPane();
        treePanel.add("Center", sp);
        treePanel.add("South", cost = new JLabel("          "));

        treePanel.setBorder(new BevelBorder(BevelBorder.RAISED));
        troot = new DefaultMutableTreeNode(projects.getName());
        tree= new JTree(troot);
        tree.setBackground(Color.lightGray);
        loadTree(projects);
        /* Put the Tree in a scroller. */

        sp.getViewport().add(tree);
        setSize(new Dimension(300, 350));
        setVisible(true);

    }
    //------------------------------------
    public void loadTree(Leaf root) {
        DefaultMutableTreeNode troot;
        troot = new DefaultMutableTreeNode(root.getName());
        treePanel.remove(tree);
        tree= new JTree(troot);
        tree.addTreeSelectionListener(this);
        sp.getViewport().add(tree);

        addNodes(troot, root);
        tree.expandRow(0);
        repaint();
    }
    //--------------------------------------

    private void addNodes(DefaultMutableTreeNode pnode, Leaf l) {
        DefaultMutableTreeNode node;

        Enumeration e = l.subordinates();
        if (e != null) {
            while (e.hasMoreElements()) {
                Leaf newLeaf = (Leaf)e.nextElement();
                node = new DefaultMutableTreeNode(newLeaf.getName());
                pnode.add(node);
                addNodes(node, newLeaf);
            }
        }
    }

    //--------------------------------------

    private void makeLeaves() {
        projects = new Composite("Projects", 40);
        projects.add(sap = new Composite("SAP", 10));
        projects.add(website = new Composite("Website", 9));
        projects.add(payroll = new Composite("Payroll", 10));
        
        sap.add(analysis = new Composite("Analysis", 50));
        sap.add(new Leaf("Requirements", 8));
        sap.add(new Leaf("Coding", 8));
        
        analysis.add(new Leaf("UML Diagram",3));
        analysis.add(new Leaf("Data Analysis",3));
        analysis.add(new Leaf("Screen Design",3));
        
        website.add(coding = new Composite("Coding", 15));
        website.add(new Leaf("Design",7));
        website.add(new Leaf("Analysis",7));
        
        coding.add(new Leaf("Prog Specs",9));
        coding.add(new Leaf("Screens",7));
        
        payroll.add(new Leaf("Design",5));
        payroll.add(new Leaf("Coding",8));
        payroll.add(new Leaf("Testing",19));
        
    }


//    private long rand_sal(long salary) {
    //    return salary +(long)(Math.random () -0.5)*salary/5;
  //  }
    //--------------------------------------
    public void valueChanged(TreeSelectionEvent evt) {
        TreePath path = evt.getPath();
        String selectedTerm = path.getLastPathComponent().toString();

        Leaf lea = projects.getChild(selectedTerm);
        if (lea != null)
            cost.setText(new Integer(lea.getTimes()).toString() + " hours");
    }
    //--------------------------------------
    static public void main(String argv[]) {
        new TaskTree();
    }
}