
public class TreeGarden extends Garden{
	public Plant getShade() {
        return new Plant("Oak" , "Peaty");
    }
    public Plant getCenter() {
        return new Plant("Ash", "Clay");
    }
    public Plant getBorder() {
        return new Plant("Apple", "Saline");
    }
}
