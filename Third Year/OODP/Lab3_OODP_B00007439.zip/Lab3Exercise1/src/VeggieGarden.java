public class VeggieGarden extends Garden {
    public Plant getShade() {
        return new Plant("Broccoli", "Clay");
    }
    public Plant getCenter() {
        return new Plant("Corn", "Sandy");
    }
    public Plant getBorder() {
        return new Plant("Peas", "Silty");
    }

}