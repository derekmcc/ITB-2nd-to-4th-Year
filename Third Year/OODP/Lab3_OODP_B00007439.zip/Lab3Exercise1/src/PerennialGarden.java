
public class PerennialGarden extends Garden {
    public Plant getShade() {
        return new Plant("Astilbe", "Peaty");
    }
    public Plant getCenter() {
        return new Plant("Dicentrum", "Clay");
    }
    public Plant getBorder() {
        return new Plant("Sedum", "Saline");
    }

}
