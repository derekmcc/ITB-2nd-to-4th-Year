
public class Plant {
    private String name;
    private String soil;
    
    public Plant(String pname, String soil) {
        name = pname;     //save name
        this.soil = soil;
    }
    public String getName() {
        return name;
    }
    public String getSoil() {
        return soil;
    }
}

