public class AnnualGarden extends Garden {
    public Plant getShade() {
        return new Plant("Coleus","Peaty");
    }
    public Plant getCenter() {
        return new Plant("Marigold", "Silty");
    }
    public Plant getBorder() {
        return new Plant("Alyssum", "Loam");
    }

}
