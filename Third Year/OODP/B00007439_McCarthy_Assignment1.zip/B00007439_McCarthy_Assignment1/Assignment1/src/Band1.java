
public class Band1 extends BandFactory {
	public Band getVocalist() {
        return new Band("Eminem", 45, "images/eminem.jpg", "Marshall Bruce Mathers III (born October 17, 1972), "
        		+ "known professionally as Eminem (often stylized as EMINƎM), is an American rapper, songwriter, record producer, and actor."
        		+ "Eminem is the best-selling artist of the 2000s in the United States. Throughout his career, he has had 10 number-one albums"
        		+ " on the Billboard 200 and five number-one singles on the Billboard Hot 100. With 47.4 million albums sold in the US and"
        		+ " 155 million records globally, he is among the world's best-selling artists. Additionally, he is the only artist to have eight albums "
        		+ " consecutively debut at number one on the Billboard 200.[1] Rolling Stone ranked him 83rd on its list of 100 Greatest Artists of "
        		+ "All Time, calling him the 'King of Hip Hop'."
        		+ "After his debut album Infinite (1996) and then Slim Shady EP (1997), Eminem signed with Dr. Dre's Aftermath "
        		+ "Entertainment and subsequently achieved mainstream popularity in 1999 with The Slim Shady LP, "
        		+ "which earned him his first Grammy Award for Best Rap Album. His next two releases, 2000's The Marshall Mathers LP and "
        		+ "2002's The Eminem Show, were worldwide successes, with each being certified diamond in U.S. sales, and both winning Best Rap Album "
        		+ "Grammy Awards—making Eminem the first artist to win the award for three consecutive LPs. They were followed by Encore in 2004, another "
        		+ "critical and commercial success. Eminem went on hiatus after touring in 2005, releasing Relapse in 2009 and Recovery in 2010."
        		+ " Both won Grammy Awards and Recovery was the best-selling album of 2010 worldwide, the second time he had the international best-selling"
        		+ " album of the year (after The Eminem Show). Eminem's eighth album, 2013's The Marshall Mathers LP 2, won two Grammy Awards, including"
        		+ "Best Rap Album; it expanded his record for the most wins in that category and his Grammy total to 15.[2] In 2017, he released "
        		+ " his ninth studio album, Revival.");
    }
    public Band getDrummer(){
        return new Band("Proof", 45, "images/proof.png", "DeShaun Dupree Holton (October 2, 1973 – April 11, 2006), better known by his stage name Proof, was an American rapper and actor from Detroit, Michigan. During his career, he was a member of the groups 5 Elementz, Funky Cowboys, Promatic, Goon Sqwad[1] and most notably, D12. He was a close childhood friend of rapper Eminem, who lived on the same block, and was often a hype man at his concerts. In April 2006, Proof was shot and killed during an altercation at the CCC nightclub in Detroit.");
    }
    public Band getGuitarist() {
        return new Band("Bizarre",41, "images/bizarre.png", "Rufus Arthur Johnson (born July 5, 1976), better known by his stage name Bizarre, is an American rapper,best known for his work with the Detroit-based hip hop group D12. Bizarre featured on D12's first EP in 1996 titled The Underground EP, before going on to release his debut solo EP titled Attack of the Weirdos in 1997. In 2001 D12 released 'Devil's Night' the debut album by D12. In 2004 he was a part of the second studio album of D12 titled D12 World. Bizarre then released his first official studio album in 2005 titled Hannicap Circus. Hannicap Circus received mixed reviews, however they were mostly bad. He also appeared on Eminem's compilation album Eminem Presents: The Re-Up, on a track called 'Murder' that also featured Kuniva, released in December 5, 2006. Following the death of rapper Proof in April 2006, D12 became inactive for some time."
        		+ "In 2007, Bizarre released his second studio album called Blue Cheese & Coney Island. In 2008, Bizarre and D12 recorded their first official mixtape titled Return of the Dozen. A sequel titled Return of the Dozen Vol. 2 followed in 2011.");
    }
    
	@Override
	public Album getAlbum1() {
		// TODO Auto-generated method stub
		return new Album("Devils Night","1 Another Public Service Announcement, 2 Shit Can Happen, 3 Pistol Pistol, 4 Nasty Mind, 5 Ain't Nuttin' But Music, 6 American Psycho, 7 Purple Pills, 8 Fight Music, 9 Instigator, 10 Pimp Like Me, 11 Blow My Buzz,"
				+ " 12 Devils Night, 13 Revelation, 14 Girls","music/d12pp.wav", "images/d12d.jpg");
	}
	@Override
	public Album getAlbum2() {
		// TODO Auto-generated method stub
		return new Album("D12's World","1 Git Up Lyrics,2 Loyalty,3 Just Like U Lyrics,4I'll Be Damned,5 My Band,6 U R the One,7 Six in the Morning,8 How Come,9 Leave Dat Boy Alone,10 Get My Gun,11 Bitch,12 Steve's Coffee House,13 D12 World,14 40 Oz,15 Commercial Break,16 American Psycho II,17 Bugz '97,18 Good Die Young","music/myBand.wav","images/d12w.jpg");
	}
	@Override
	public Album getAlbum3() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Album getAlbum4() {
		// TODO Auto-generated method stub
		return null;
	}
}
