
public abstract class BandFactory {
	public abstract Band getVocalist();
    public abstract Band getGuitarist();
    public abstract Band getDrummer();
    public abstract Album getAlbum1();
    public abstract Album getAlbum2();
    public abstract Album getAlbum3();
    public abstract Album getAlbum4();
}//end class	
