import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.print.DocFlavor.URL;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class AlbumPanel extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BandFactory band = null;
	Container contentPane = getContentPane();
	JButton btnAlbum1, btnAlbum2, btnAlbum3, btnAlbum4, btnPlay, btnStop, btnBack;
	JTextArea list;
	JLabel lblAlbums;
	ArrayList<String> arrayList;
	JPanel btnPanel,wrapper,panel,outWrap, audioPanel,lblPanel,albumPanel;
	AudioClip audio;
	private int height = 750, width = 650;
	
	public AlbumPanel(Object obj) {
		super("Albums");
		band = (BandFactory) obj;
		
		Font listFont = new Font(("SansSerif"), Font.BOLD,16); 
		
		list = new JTextArea(15, 25);
		lblAlbums = new JLabel();
		list.setEditable(false);
		list.setLineWrap(true);
		list.setText("Choose an album below to view its tracklist.\nTo play a sample from the chosen album\nclick play -->");
		list.setFont(listFont);
		//create the panels
		btnPanel = new JPanel();
		panel = new JPanel();
		wrapper = new JPanel();
		outWrap = new JPanel();
		audioPanel = new JPanel();
		lblPanel = new JPanel();
		albumPanel = new JPanel();
		
		btnPlay = new JButton("Play");
		btnStop = new JButton("Stop");
		btnBack = new JButton("Back To Main Menu"); 
		
		btnPlay.setBackground(Color.green);
		btnStop.setBackground(Color.red);
		
		lblPanel.add(lblAlbums);
		
		Dimension dn = new Dimension(100,50);
		
		if (band.getAlbum1() != null && band.getAlbum2() != null && band.getAlbum3() != null && band.getAlbum4() != null) {
			
			ImageIcon img1 = new ImageIcon(band.getAlbum1().getImage());
			ImageIcon img2 = new ImageIcon(band.getAlbum2().getImage());
			ImageIcon img3 = new ImageIcon(band.getAlbum3().getImage());
			ImageIcon img4 = new ImageIcon(band.getAlbum4().getImage());
			
			btnAlbum1 = new JButton(new ImageIcon());
			btnAlbum2 = new JButton(new ImageIcon());
			btnAlbum3 = new JButton(new ImageIcon());
			btnAlbum4 = new JButton(new ImageIcon());
			
			btnAlbum1.setIcon(img1);
			btnAlbum2.setIcon(img2);
			btnAlbum3.setIcon(img3);
			btnAlbum4.setIcon(img4);
			
			btnAlbum1.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum2.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum3.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum4.setMargin(new Insets(0, 0, 0, 0));
		
			btnPanel.add(btnAlbum1);
			btnPanel.add(btnAlbum2);
			btnPanel.add(btnAlbum3);
			btnPanel.add(btnAlbum4);
			
			btnAlbum1.addActionListener(this);
			btnAlbum2.addActionListener(this);
			btnAlbum3.addActionListener(this);
			btnAlbum4.addActionListener(this);
			height = 750;
			btnPanel.setLayout(new GridLayout(2,2,10,10));
		} 
		else if (band.getAlbum1() != null && band.getAlbum2() != null && band.getAlbum3() != null && band.getAlbum4() == null) {
			btnAlbum1 = new JButton("1");
			btnAlbum2 = new JButton("2");
			btnAlbum3 = new JButton("3");
			
			ImageIcon img1 = new ImageIcon(band.getAlbum1().getImage());
			ImageIcon img2 = new ImageIcon(band.getAlbum2().getImage());
			ImageIcon img3 = new ImageIcon(band.getAlbum3().getImage());
			btnAlbum1.setIcon(img1);
			btnAlbum2.setIcon(img2);
			btnAlbum3.setIcon(img3);
			
			btnAlbum1.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum2.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum3.setMargin(new Insets(0, 0, 0, 0));
			
			btnPanel.add(btnAlbum1);
			btnPanel.add(btnAlbum2);
			btnPanel.add(btnAlbum3);
			
			btnAlbum1.addActionListener(this);
			btnAlbum2.addActionListener(this);
			btnAlbum3.addActionListener(this);
			height = 750;
			btnPanel.setLayout(new GridLayout(1,3,10,10));
		} 
		else if (band.getAlbum1() != null && band.getAlbum2() != null && band.getAlbum3() == null && band.getAlbum4() == null) {
			btnAlbum1 = new JButton("");
			btnAlbum2 = new JButton("");
			
			ImageIcon img1 = new ImageIcon(band.getAlbum1().getImage());
			ImageIcon img2 = new ImageIcon(band.getAlbum2().getImage());
			
			btnAlbum1.setIcon(img1);
			btnAlbum2.setIcon(img2);
			
			btnPanel.add(btnAlbum1);
			btnPanel.add(btnAlbum2);
			
			btnAlbum1.setMargin(new Insets(0, 0, 0, 0));
			btnAlbum2.setMargin(new Insets(0, 0, 0, 0));
			
			btnAlbum1.addActionListener(this);
			btnAlbum2.addActionListener(this);
			height = 620;
			btnPanel.setLayout(new GridLayout(1,2,10,10));
		}
		else if (band.getAlbum1() != null && band.getAlbum2() == null && band.getAlbum3() == null && band.getAlbum4() == null) {
			btnAlbum1 = new JButton("");
			
			ImageIcon img1 = new ImageIcon(band.getAlbum1().getImage());
			btnAlbum1.setIcon(img1);
			
			btnAlbum1.setMargin(new Insets(0, 0, 0, 0));
			
			btnPanel.add(btnAlbum1);
			
			btnAlbum1.addActionListener(this);
			height = 620;
			
		}//end else if
		
		btnPlay.addActionListener(this);
		btnStop.addActionListener(this);
		btnBack.addActionListener(this);
		
		btnPlay.setEnabled(false);
		btnStop.setEnabled(false);
		
		btnPlay.setPreferredSize(dn);
		
		audioPanel.setLayout(new GridLayout(3,1,15,15));
		
		audioPanel.add(btnPlay);
		audioPanel.add(btnStop);
		audioPanel.add(btnBack);
		
		JLabel label = new JLabel("Album Track Listing");
		JPanel lblPanel = new JPanel();
		lblPanel.add(label);
		panel.add(list);	
		panel.add(audioPanel);
		//list.setText("");
		outWrap.add(btnPanel, BorderLayout.SOUTH);
		wrapper.add(panel, BorderLayout.NORTH);
		wrapper.add(outWrap, BorderLayout.SOUTH);
		
		contentPane.add(wrapper);
		 
		//set the size, visibility, resizability & position of the frame
		setSize(width,height);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnAlbum1){
			if(audio != null){
				audio.stop();
			}//end if
			list.setText(band.getAlbum1().getTracks().replaceAll(",", "\n"));	
			java.net.URL urlClick = AlbumPanel.class.getResource(band.getAlbum1().getSample());
			audio = Applet.newAudioClip(urlClick);
			btnPlay.setEnabled(true);	
		}//end if
		else if (e.getSource() == btnAlbum2){
			if(audio != null){
				audio.stop();
			}//end if
			list.setText(band.getAlbum2().getTracks().replaceAll(",", "\n"));
			java.net.URL urlClick = AlbumPanel.class.getResource(band.getAlbum2().getSample());
			audio = Applet.newAudioClip(urlClick);
			btnPlay.setEnabled(true);
		}//end else if
		else if (e.getSource() == btnAlbum3){
			if(audio != null){
				audio.stop();
			}//end if
			list.setText(band.getAlbum3().getTracks().replaceAll(",", "\n"));	
			java.net.URL urlClick = AlbumPanel.class.getResource(band.getAlbum3().getSample());
			audio = Applet.newAudioClip(urlClick);
			btnPlay.setEnabled(true);
		}//end else if
		else if (e.getSource() == btnAlbum4){
			if(audio != null){
				audio.stop();
			}//end if
			list.setText(band.getAlbum4().getTracks().replaceAll(",", "\n"));	
			java.net.URL urlClick = AlbumPanel.class.getResource(band.getAlbum4().getSample());
			audio = Applet.newAudioClip(urlClick);
			btnPlay.setEnabled(true);
		}//end else if
		if (e.getSource() == btnPlay){
			audio.play();
			btnStop.setEnabled(true);
			btnPlay.setEnabled(false);
		}//end if
		if (e.getSource() == btnStop){
			if(audio != null){
				audio.stop();
			}
			btnPlay.setEnabled(true);
			btnStop.setEnabled(false);
		}//end if
		if (e.getSource() == btnBack){
			if(audio != null){
				audio.stop();
			}
			this.dispose();
			new MainTest();
		}//end if
	}//end actionPerformed

}//end class
