
public class Band {
	private String name, image, desc;
	private int age;
	
	public Band(String name, int age, String image, String desc) {
        this.name = name;
        this.age = age;
        this.image = image;
        this.desc = desc;
    }
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}//end class
