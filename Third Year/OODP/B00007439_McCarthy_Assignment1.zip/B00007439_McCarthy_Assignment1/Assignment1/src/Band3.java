
public class Band3 extends BandFactory {
	public Band getVocalist() {
        return new Band("Bono", 57, "images/bono.jpg", "Paul David Hewson, OL (born 10 May 1960), known by his stage name Bono, is an Irish singer-songwriter, musician, venture capitalist, businessman, and philanthropist. He is best known as the lead vocalist and primary lyricist of rock band U2."
        		+ "Bono was born and raised in Dublin, Ireland. He attended Mount Temple Comprehensive School where he met his future wife, Alison Stewart, as well as schoolmates with whom he founded U2 in 1976. Bono soon established himself as a passionate frontman for the band through his expressive vocal style and grandiose gestures and songwriting. His lyrics are known for their social and political themes, and for their religious imagery inspired by his Christian beliefs. During U2's early years, Bono's lyrics contributed to the group's rebellious and spiritual tone. As the band matured, his lyrics became inspired more by personal experiences shared with the other members. As a member of U2, Bono has received 22 Grammy Awards and has been inducted into the Rock and Roll Hall of Fame."
        		+ "Bono is widely known for his activism for social justice causes, both through U2 and as an individual. He is particularly active in campaigning for Africa, for which he co-founded DATA, EDUN, the ONE Campaign, and Product Red. In pursuit of these causes, he has participated in benefit concerts and met with influential politicians. Bono has been praised for his philanthropic efforts; he was granted an honorary knighthood by Elizabeth II of the United Kingdom for 'his services to the music industry and for his humanitarian work', and has been made a Commandeur of the French Ordre des Arts et des Lettres (Order of Arts and Letters). In 2005, Bono was named one of the Time Persons of the Year."
        				+ "Outside the band, he has recorded with numerous artists. He has collaborated with U2 bandmate the Edge on several projects, including: songs for Roy Orbison and Tina Turner; the soundtracks to the musical Spider-Man: Turn Off the Dark and a London stage adaptation of A Clockwork Orange; and the refurbishment of the Clarence Hotel in Dublin. He is Managing Director and a Managing Partner of the private equity firm Elevation Partners, which has invested in several companies.");
    }//end getVocalist
    public Band getDrummer(){
        return new Band("The Edge", 56, "images/edge.jpg", "David Howell Evans (born 8 August 1961), better known by his stage name the Edge (or just Edge),[1] is an Irish musician and songwriter best known as the lead guitarist, keyboardist and backing vocalist of the rock band U2. A member of the group since its inception, he has recorded 14 studio albums with the band as well as one solo record. As a guitarist, the Edge has crafted a minimalistic and textural style of playing. His use of a rhythmic delay effect yields a distinctive ambient, chiming sound that has become a signature of U2's music");
    }
    public Band getGuitarist() {
        return new Band("Larry Mullen Jr.", 56, "images/larry.jpg", "Laurence Joseph Mullen Jr. (born 31 October 1961) is an Irish musician and actor, best known as the drummer of the Irish rock band U2.[1] Mullen's distinctive drumming style developed from his playing martial beats in a childhood marching band, the Artane Boys Band. Some of his most notable contributions to the U2 catalogue include 'Sunday Bloody Sunday', 'Pride (In the Name of Love)', 'Where the Streets Have No Name', 'Zoo Station,' 'Mysterious Ways', and 'City of Blinding Lights'.");
    }//end getGuitarist
	@Override
	public Album getAlbum1() {
		// TODO Auto-generated method stub
		return new Album("HOW TO DISMANTLE AN ATOMIC BOMB","1 Vertigo,2 Miracle Drug,3 Sometimes You Can't Make it On Your Own Lyrics,4 Love And Peace Or Else,5 City Of Blinding Lights,6 All Because Of You,7 A Man and A Woman,8 Crumbs From Your Table Lyrics,9 One Step Closer,10 Original Of The Species,11 Yahweh,12 Fast Cars","music/ver.wav","images/u2.jpg");
	}
	@Override
	public Album getAlbum2() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Album getAlbum3() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Album getAlbum4() {
		// TODO Auto-generated method stub
		return null;
	}
}
