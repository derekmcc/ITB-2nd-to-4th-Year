
public class Band4 extends BandFactory  {
	public Band getVocalist() {
        return new Band("50 Cent", 42, "images/50.jpg", "Curtis James Jackson III (born July 6, 1975), known professionally as 50 Cent, is an American rapper, actor, businessman, and investor. Born in the South Jamaica neighborhood of the borough of Queens, Jackson began selling drugs at age twelve during the 1980s crack epidemic. He later began pursuing a musical career and in 2000 he produced Power of the Dollar for Columbia Records, but days before the planned release he was shot nine times and the album was never released. In 2002, after Jackson released the compilation album Guess Who's Back?, he was discovered by Eminem and signed by Shady Records, Aftermath Entertainment and Interscope Records."
        		+ "With the aid of Eminem and Dr. Dre (who produced his first major-label album, Get Rich or Die Tryin'), Jackson became one of the world's best selling rappers and rose to prominence with East Coast hip hop group G-Unit (which he leads de facto). In 2003, he founded G-Unit Records, signing his G-Unit associates Young Buck, Lloyd Banks and Tony Yayo. Jackson had similar commercial and critical success with his second album, The Massacre, which was released in 2005. He released his fifth studio album, Animal Ambition, in 2014 and is working on his sixth studio album, Street King Immortal. He executive produces and stars in the show Power, which airs on Starz.");
    }
    public Band getDrummer(){
        return new Band("Lloyd Banks", 35, "images/lloyd.jpg", "Christopher Charles Lloyd (born April 30, 1982), better known by his stage name Lloyd Banks, is an American hip hop recording artist and member of East Coast hip hop group G-Unit, alongside childhood friends and fellow American rappers, 50 Cent and Tony Yayo. Raised in South Jamaica, Queens, he dropped out of high school in 1998. G-Unit released two albums, Beg for Mercy in 2003 and T.O.S. (Terminate on Sight) in 2008. Banks released his first solo album The Hunger for More in 2004 with the top ten hit single 'On Fire'. He followed with Rotten Apple in 2006 and left Interscope Records 2009. In 2010 G-Unit signed with EMI to distribute Banks third studio album The Hunger for More 2, which was released on November 22, 2010");
    }
    public Band getGuitarist() {
        return new Band("Tony Yayo", 39, "images/tony.jpg", "Marvin Bernard (born March 31, 1978) is an American rapper, hype man, and member of the hip hop group G-Unit better known by his stage name Tony Yayo. Tony Yayo was brought up in South Jamaica, Queens, New York, where he met his longtime friends 50 Cent and Lloyd Banks. He is currently signed to 50 Cent's record label G-Unit Records, and is also signed with EMI to release his second untitled album. He is CEO to the label G-Unit Philly. His stage name is derived from the 1983 film Scarface, referencing the character Tony Montana and the slang word for cocaine.");
    }
	@Override
	public Album getAlbum1() {
		// TODO Auto-generated method stub
		return new Album("Beg For Mercy","1 G-Unit,2 Poppin' Them Thangs,3 My Buddy,4 I'm So Hood,5 Stunt 101,6 Wanna Get to Know You,7 Groupie Love,8 Betta Ask Somebody,9 Footprints,10 Eye for Eye,11 Smile,12 Baby U Got,13 Salute U,14 Beg for Mercy,15 G'd Up,16 Lay You Down,17 Gangsta Shit,18 I Smell P***y","music/gunit.wav","images/bfm.jpg");
	}
	@Override
	public Album getAlbum2() {
		// TODO Auto-generated method stub
		return new Album("Terminate On Site","1 Straight Outta Southside,2 Piano Man - Feat. Young Buck,3 Close To Me,4 Rider Pt. 2 - Feat. Young Buck,5 Casualties Of War,6 You So Tough,7 No Days Off - Feat. Young Buck,8 T.O.S.,9 I Like The Way She Do It - Feat. Young Buck,10 Kitty Kat,11 Party Ain�t Over - Feat. Young Buck,12 Let It Go - Feat. Mavado,13 Get Down,14 I Don�t Want To Talk About It,15 Ready Or Not,16 Money Make The World Go Around","music/gpdt.wav","images/tos.jpg");
	}
	@Override
	public Album getAlbum3() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Album getAlbum4() {
		// TODO Auto-generated method stub
		return null;
	}
}
