
public class Band2 extends BandFactory {
	public Band getVocalist() {
        return new Band("Danny O'Donoghue", 38, "images/dannyO.jpg", "Danny O'Donoghue was born in Dublin, Ireland to Shay O'Donoghue, a member of the band The Dreams, and Ailish O'Donoghue. He is the youngest of six children and was raised in Ballinteer, Dublin.[1] As a child, he was initially against the idea of being a musician; however, he ended up dropping out of school to pursue a musical career");
    }
    public Band getDrummer(){
        return new Band("Glen Power", 39, "images/glen.jpg", "Indie pop drummer who occasionally provided background vocals in the Irish rock band The Script alongside singer and guitarist Mark Sheehan and lead singer Danny O'Donoghue.");
    }
    public Band getGuitarist() {
        return new Band("Mark Sheehan", 38, "images/markS.jpeg", "Indie singer and guitarist who became a member of The Script alongside singer Danny O'Donoghue and drummer Glen Power in 2001.");
    }
	@Override
	public Album getAlbum1() {
		// TODO Auto-generated method stub
		return new Album("The Script","1 We Cry,2 Before The Worst,3 Talk You Down,4 The Man Who Can't Be Moved,5 Breakeven,6 Rusty Halo,7 The End Where I Begin,8 Fall For Anything,9 If You See Kay,10 I'm Yours,11 Anybody There","music/wec.wav","images/thescript.jpg");
	}
	@Override
	public Album getAlbum2() {
		// TODO Auto-generated method stub
		return new Album("Science & Faith", "1 You Won't Feel A Thing,2 For The First Time,3 Nothing,4 Science & Faith,5 If You Ever Come Back,6 Long Gone And Moved On,7 Dead Man Walking,8 This = Love,9 Walk Away,10 Exit Wounds","music/ftft.wav","images/sf.jpg");
	}
	@Override
	public Album getAlbum3() {
		// TODO Auto-generated method stub
		return new Album("#3","1 Good Ol' Days,2 Six Degrees Of Separation,3 Hall Of Fame,4 If You Could See Me Now,5 Glowing,6 Give The Love Around,7 Broken Arrow,8 Kaleidoscope,9 No Words,10 Millionaires","music/hof.wav","images/thes.jpg");
	}
	@Override
	public Album getAlbum4() {
		// TODO Auto-generated method stub
		return new Album("No Sound Without Silence","1 No Good In Goodbye,2 Superheroes,3 Man On A Wire,4 It's Not Right For You,5 The Energy Never Dies,6 Flares,7 Army Of Angels,8 Never Seen Anything 'Quite Like You',9 Paint The Town Green,10 Without Those Songs,11Hail Rain Or Sunshine","music/sup.wav","images/no.jpg");
	}
}
