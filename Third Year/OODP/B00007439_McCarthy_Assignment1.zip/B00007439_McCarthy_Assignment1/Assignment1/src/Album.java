
public class Album {
	
	private String tracks;
	private String album;
	private String sample;
	private String image;
	
	public Album(String album,String tracks, String sample, String image) {
		this.album = album;
		this.tracks = tracks;
		this.sample = sample;
		this.image = image;
	}//end constructor
	
	public String getSample() {
		return sample;
	}

	public void setSample(String sample) {
		this.sample = sample;
	}

	public String getTracks() {
		return tracks;
	}

	public void setTracks(String tracks) {
		this.tracks = tracks;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
}//end class
